const char *SIGN_winnat_c="{FILESIGN=winssl.c:20141026143034+0900:79d37d663ff55542:Author@DeleGate.ORG:XP/jmWJNZNdK53DRkSI4IYKk+GaBarYZRe2ZDKhW0rg8nmmIqFLOWhmYrYh+Mwl2Ov+DtQBT/6yL3mgD+ISxRuVefz/J9TiI8tUWtfKleSYTC//0XliQX5kKqKxhXWAxG0jyaNX4Kvs3TMe7CYH+sUUJgJBJY4ecuVq3R2pq6PU=}";

/*////////////////////////////////////////////////////////////////////////
Copyright (c) 2008 National Institute of Advanced Industrial Science and Technology (AIST)
AIST-Product-ID: 2000-ETL-198715-01, H14PRO-049, H15PRO-165, H18PRO-443

Permission to use this material for noncommercial and/or evaluation
purpose, copy this material for your own use,
without fee, is hereby granted
provided that the above copyright notice and this permission notice
appear in all copies.
AIST MAKES NO REPRESENTATIONS ABOUT THE ACCURACY OR SUITABILITY OF THIS
MATERIAL FOR ANY PURPOSE.  IT IS PROVIDED "AS IS", WITHOUT ANY EXPRESS
OR IMPLIED WARRANTIES.
//////////////////////////////////////////////////////////////////////////
Content-Type:	program/C; charset=US-ASCII
Program:	winnat.c (NAT on Windows)
Author:		Yutaka Sato <y.sato@delegate.org>
Description:

History:
//////////////////////////////////////////////////////////////////////#*/
/* '"DIGEST-OFF"' */


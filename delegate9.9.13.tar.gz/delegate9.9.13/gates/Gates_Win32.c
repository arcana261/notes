const char *SIGN_Gates_Win32_c="{FILESIGN=Gates_Win32.c:20141031194211+0900:29af5fcce28b073c:Author@DeleGate.ORG:Mls1XqSzY8Y9estOTI9rP+6MArh1wnBIF4xg2GogsHM7G5acSegKBB1vRUvsL8D+rDrupv8rvQcaN3rSF5Rb2Y8SuaRsLLpeolc2jBJlTyl0kDrEr7jzcGWPlodx0TxyMX+OhbPwBsw/CCasGzZduMY57u/Scv3RiTlQgYZgdMg=}";

/*////////////////////////////////////////////////////////////////////////
Copyright (c) 2014 Yutaka Sato
//////////////////////////////////////////////////////////////////////////
Content-Type:	program/C; charset=US-ASCII
Program:	Gates_Win32.c
Author:		Yutaka Sato <ysato@delegate.org>
Description:
History:
	141026	created
//////////////////////////////////////////////////////////////////////#*/
/* '"DIGEST-OFF"' */


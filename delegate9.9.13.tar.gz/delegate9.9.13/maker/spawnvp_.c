#include <sys/wait.h>

int INHERENT_spawn(){ return 0; }
int SPAWN_P_NOWAIT = 0;
int SPAWN_P_WAIT = 0;

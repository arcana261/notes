int Mkfifo(const char *path,int mode){
	return -1;
}

#ifndef _MSC_VER
#include "ystring.h"
int strfRusage(PVStr(usg),PCStr(fmt),int who,PCStr(sru)){
	setVStrEnd(usg,0);
	return 0;
}
#endif

#ifdef _MSC_VER
#define alloca(z) _alloca(z)
#else
#include <alloca.h>
#endif
#include "__alloca.c"

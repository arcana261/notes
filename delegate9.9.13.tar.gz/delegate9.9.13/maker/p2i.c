#include "ystring.h"
int p2iX(FL_PAR,const void *p){
	return 0xFFFFFFFF & ((Int64)p);
}

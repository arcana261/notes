int INHERENT_futimes(){ return 0; }
int Futimes(int fd,int as,int au,int ms,int mu){
	return -1;
}

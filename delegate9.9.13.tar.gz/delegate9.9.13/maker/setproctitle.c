#include "ystring.h"
int Setproctitle(const char *fmt,...){
	return -1;
}

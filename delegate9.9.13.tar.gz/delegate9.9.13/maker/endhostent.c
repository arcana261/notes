int SUBST_endhostent = 1;

void endhostent(){
}

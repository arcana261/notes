int SUBST_strerr = 1;

int strerror()
{
	return 0;
}

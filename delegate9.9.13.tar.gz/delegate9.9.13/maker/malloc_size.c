int mallocSize(void *p){
	return -1;
}

/* __CYGWIN__ does not have errno ...
 */
#ifndef __cplusplus
int errno;
#endif

int SUBST_fsync = 1;

int fsync(/*int fd*/)
{
	return -1;
}

int SUBST_closesocket = 1;

int SocketOf(int sock)
{
	return sock;
}

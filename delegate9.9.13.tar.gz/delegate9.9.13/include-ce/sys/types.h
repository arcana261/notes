typedef long int off_t;
typedef long int __time32_t;

#define LIBRARY
#include "smtp.c" /*{inline}*/

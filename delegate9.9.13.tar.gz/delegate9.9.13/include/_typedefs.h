/*
 * type definitions
 */
